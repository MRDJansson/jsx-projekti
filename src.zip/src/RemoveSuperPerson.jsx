import useStore from "./stores/Store";

function RemoveSuperPerson({ name }) {
  const removeSuperPerson = useStore((state) => state.removeSuperPerson);

  const handleRemove = (e) => {
    removeSuperPerson(name); // Poistetaan superhenkilö nimen perusteella
  };

  return (
    <div
      onClick={handleRemove} // Poistaa superhenkilön, kun koko alue klikataan
       // Täyttää koko alueen
    />
  );
}

export default RemoveSuperPerson;
