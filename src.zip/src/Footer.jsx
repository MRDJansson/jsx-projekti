function Footer() {
    return (
      <footer className="border-t text-xs text-center text-muted-foreground px-6 py-4">
        <p>&copy; 2020 Supersofta</p>
      </footer>
    );
  }
  
  export default Footer;
  